# Pop & Ladle — Change Reference
## Clinical Review Gate Rework + Catalog Wiring

**Date:** 2026-06-25
**Scope of this rework:** the Clinical Review Gate model, the external data catalogs, and per-person nutrition — propagated across blueprints, the ABAC matrix, the Master Library recipe profile, the screen inventory, and the recipe intake rules.
**Audience:** the full-stack developer, and any future Claude session picking this up.

---

## 0. How to use this file

This is the single source of "what changed and why." If you are starting fresh:

1. Read §1 (the three decisions) — that's the *why* behind every file change.
2. Read §2 (data objects/fields) and §3 (permissions) — the canonical shapes.
3. Use §5 (per-file log) to see exactly what changed in each file and whether you still need to act on it.
4. §7 lists what's intentionally unchanged and what's still open.

**Authority order when files disagree:** the handoff docs (§5.G) define the gate model and win on the gate; the blueprints are the upstream architecture; the ABAC matrix, recipe profile, screen inventory, and validation rules are downstream artifacts that must conform to the blueprints + handoff. Data flows down, not up.

---

## 1. The three decisions driving every change

**A. The gate is a flag, not a wall (two-axis).**
The Clinical Review Gate produces two independent results:
- **System verdict** (AI synthesis): `approved`, `approved_with_caveats`, `denied`, `needs_clinical_review`, `needs_nutrition_verification`, `needs_household_adaptation`.
- **Human clinical attestation** (optional): `none` or `attested`, added by a Super Admin OR an admin with an active verified clinical credential — credential-gated, not role-title-gated.

Rules: **`denied` is the only hard stop.** Everything else publishes with a **non-suppressible badge** — "Clinically reviewed" (attested) or "AI-reviewed, not clinically verified" (none). Absence of human attestation never blocks publishing. Every recipe still passes *through* the gate (no bypass on pass-through).

**B. Generation is two-mode.**
- **Generic** (`careRecipientId == null`): no Care Profile/hard rules injected → Master Library candidate, `personalized: false`.
- **Personalized** (`careRecipientId` set): Care Profile + Hard Rule passes inject the person's data → Household Recipe Copy, `personalized: true`.
- Never present a generic recipe as personalized.

**C. Nutrition is FDC-sourced and per-person-conditional.**
- Nutrient **values** come from **USDA FoodData Central** (via the internal Nutrition Catalog) for **every** recipe, attestation or not, generic or personalized. The AI never invents nutrient numbers.
- **Hard Rule** = binary/absolute (e.g. "no shellfish"). **Intake Limit** = optional numeric ceiling/target for one nutrient, one person.
- A nutrient is *verified/displayed* only when that person has a limit on it; values are always *computed*. Unmatched ingredients are flagged (never zeroed) and routed to the Nutrition Verification Queue.

**Naming:** FoodData Central is **USDA**, not FDA. USDA = food/nutrient truth. FDA = drug listing, NDC, labeling, adverse events, recalls.

---

## 2. Data objects & fields (canonical)

### New objects
- **`clinical_attestation`** — `id, recipeId, recipeVersionId, runId, attestedBy, credentialRef (required), decision (attested|revoked), reasoning (required), attestedAt, versionLock, auditEntryId`. Created only if caller is Super Admin OR has an active `verified_credential`. Editing the recipe resets `attestationState` to `none` (prior attestation retained, append-only).
- **`verified_credential`** — `id, userId, credentialType, licenseRef, verifiedBy, verifiedAt, active, expiresAt`. MVP: Super Admin seeds manually.
- **`care_intake_limit`** — `id, careRecipientId, nutrient, limitType (ceiling|target|floor), value, unit, window (per_day|per_meal|per_serving), setBy, source (owner|co_owner|clinician_import), createdAt, auditEntryId`. Optional, per person.

### Modified objects
- **`recipe_generation_run`** — added `personalized`, `intakeLimitCount`, `appliedLimits[]`, `nutritionSource ("usda_fdc")`, `catalogVersions {fdc, icd10cm, rxnorm}`.
- **`recipe`** — added `personalized`, `attestationState (none|attested)`, `currentAttestationId`, `publishState (publishable|stopped; stopped iff status==denied)`, `nutrition {}` (FDC-sourced).
- **`recipe.nutrition`** — `source ("usda_fdc"), computedAt, ingredients[{raw, fdcId, matchConfidence, nutrients{}}], totals{}, unmatchedIngredients[], overallConfidence`. Always computed; display gated per Decision C.
- **`care_diagnosis`** — added `icd10Code, label, icd10Version, confirmationSource, activatedModules[]`.
- **`care_medication`** — added `rxcui, ingredient, brand, strength, doseForm, route, drugClass[], ndc, splSetId, rxnormVersion, foodTimingRule`.
- **`audit_log`** — append-only coverage for: attest, revoke, intake-limit CRUD, diagnosis/medication CRUD (with source IDs + catalog versions), nutrition-catalog corrections, publish-state change, run completion.

`publishState = (clinicalReviewStatus == "denied") ? "stopped" : "publishable"` — derived, not user-set.

---

## 3. Permissions / capabilities (new + changed)

New capability tokens (now in the ABAC Capability Dictionary):
- `recipe:clinical_attest` — add a human attestation. **Credential-gated**, not role-title.
- `recipe:clinical_attest:revoke` — revoke an attestation (Super Admin or original attester).
- `recipe:clinical_deny` — set verdict to Denied (the single hard stop).
- `clinical_limit:set` — create/edit a per-person intake limit (Owner/Co-Owner in MVP household; clinicians in clinical surfaces).
- `attr:credential:clinical:verified` — **attribute, not a role**: principal holds an active verified clinical credential; required to attest.

Role changes:
- **Global Super Admin (PL-001):** may attest (credential-gated); gate relation now "only_denied_blocks; can_attest_credentialed."
- **Clinician Reviewer (PL-059):** reframed from "mandatory before ship" to optional/authoritative attestation; gained attest/revoke/deny; gate relation "attests_optional_authoritative; can_deny."
- **Internal gate reviewers (PL-060/061/062):** tagged `attr:credential:clinical:verified`.
- **Owner (PL-069) & Co-Owner (PL-070):** gained `clinical_limit:set`.
- **Badge suppression:** allowed by nobody.

---

## 4. New screens

| Screen ID | Screen | Surface / Layer | Purpose |
|---|---|---|---|
| PL-L3-HH-LIMITS | Intake Limits Management | Private Household App / L3 | Owner/Co-Owner set per-person intake limits; optional |
| PL-L2-CLIN-ATTEST | Clinical Attestation Console | Internal Clinical Review / L2 | Credential-gated attest/revoke; optional; only Denied blocks |
| PL-L1-CTRL-CRED | Verified Credential Management | Super Admin Control Plane / L1 | Verify/manage credentials that gate attestation |
| PL-L2-CLIN-NUTRIQ | Nutrition Verification Queue | Internal Data Workspace / L2 | Re-verify nutrition vs USDA FDC; resolve unmatched ingredients |

Cross-cutting UI: the **non-suppressible clinical badge** must appear on every recipe-display screen (library card, detail, print, copy-into-household, planner attachment), plus a nutrition-provenance label ("Nutrition from USDA FoodData Central") and a personalization label (generic vs personalized).

---

## 5. Per-file change log

### A. Pop & Ladle System Blueprint (standalone).html — CHANGED
- Care Profile Foundation (2B): added a **"Source catalogs · external data truth"** block (Diagnoses · ICD-10-CM, Medications · RxNorm, Med display · RxTerms, Drug class · RxClass/MED-RT, Product · FDA NDC, Drug label · DailyMed SPL, Nutrient values · USDA FoodData Central).
- Recipe pipeline: step 10 now reads **"Nutrition Verification · USDA FoodData Central."**
- Gate callout rewritten to the two-axis model (system verdict + optional credentialed attestation; only Denied stops; publishes flagged).

### B. Pop & Ladle Layer 1 Control Plane Blueprint (standalone).html — CHANGED
- Gate callout updated (only Denied blocks; everything else publishes flagged).
- New **"Callout / Attestation"** (optional, credential-gated; never blocks publishing).
- New **"Callout / Catalog governance"** (ICD-10-CM, RxNorm, USDA FDC versions pinned + audited; Nutrition Data Manager owns FDC mappings; Nutrition Verification Queue re-verifies on catalog change).

### C. Pop & Ladle Layer 2 Platform Blueprint (standalone).html — CHANGED
- Care Profile: added a **"Source catalogs"** sibling module.
- Recipe services: **Nutrition Verification Service · USDA FoodData Central.**
- Gate tag "No bypass" retained intentionally (pass-through is still mandatory; accurate under the new model).

### D. Pop & Ladle Layer 3 Surfaces Blueprint (standalone).html — CHANGED
- Care Profile Setup: added a **"Source catalogs"** sibling module.

### E. Pop & Ladle User Journey Blueprint Set (standalone).html — CHANGED
- Care Profile entry steps now read **"Diagnoses · ICD-10"** and **"Meds and timing · RxNorm."**

### F. Pop & Ladle Architecture Plan-060112026.html — UNCHANGED
- No care-profile/catalog data section present; nothing to wire.

### G. clinical-review-gate-handoff-final.md / -with-openapi.md — CREATED (handoff)
- Full developer spec for the rework: two-axis gate, two-mode generation, FDC nutrition, data model, permissions, gate state machine, migration, QA, open decisions. The `-with-openapi` variant adds an OpenAPI 3.1 stub for attest/revoke, intake-limit CRUD, and ICD-10/RxNorm lookups. **These define the gate model; they win on conflicts.**

### H. pop_ladle_abac_role_matrix.xlsx / .csv — CHANGED
- See §3. Four sheets preserved (Role Matrix, Tiers, Capability Dictionary, Scope Grammar). CSV regenerated in sync with the xlsx Role Matrix sheet.

### I. pop_ladle_master_library_recipe_profile — v3.1 → v3.2 — CHANGED
- New "Clinical Attestation (Two-Axis Gate)" section (state, credential ref, reasoning, version lock).
- Release rules: only DENIED blocks; ships flagged "AI-reviewed, not clinically verified" without attestation.
- Nutrition Snapshot: USDA FoodData Central named as the nutrient source of truth (record FDC food ID per ingredient).
- Caregiver-card "Approval status" tied to the non-suppressible badge.
- (Catalogs were already wired in this file via the External Verification Boundary — unchanged there.)

### J. Pop_Ladle_Master_Screen_Inventory.xlsx — CHANGED
- Workflow Gates: Clinical Review Gate row updated to two-axis blocking semantics.
- +4 screens (see §4) added to the main sheet and to the Screen States / Screen Actions / Audit Events detail sheets.
- Aggregate/rollup sheets (Surface Map, Phase Map, counts) not recomputed — treat counts as approximate until regenerated.

### K. Pop_Ladle_Master_Screen_Inventory.html — CHANGED
- Gate descriptor updated from "MANDATORY · NO BYPASS" to "PASS-THROUGH · ONLY DENIED BLOCKS" with the two-axis explanation.
- Revision addendum appended listing the four new screens + the badge requirement. (The xlsx is the authoritative source; the HTML is a render.)

### L. recipe_text_intake_validation_rules.md — CHANGED
- Added "Nutrition Is Not an Intake Field" (FDC supplies values downstream; unmatched flagged, not zeroed).
- Added "After Validation — Two-Axis Clinical Review" (dispatch → gate → verdict + optional attestation; only Denied stops).

---

## 6. Filenames & re-upload guidance

Blueprints use the display names **with spaces, "&", and parentheses** — replace these in the project (delete old, upload same-named new):
- Pop & Ladle System Blueprint (standalone).html
- Pop & Ladle Layer 1 Control Plane Blueprint (standalone).html
- Pop & Ladle Layer 2 Platform Blueprint (standalone).html
- Pop & Ladle Layer 3 Surfaces Blueprint (standalone).html
- Pop & Ladle User Journey Blueprint Set (standalone).html

Downstream artifacts use underscore names:
- pop_ladle_abac_role_matrix.xlsx / .csv
- pop_ladle_master_library_recipe_profile_v3_2.md (supersedes v3_1)
- Pop_Ladle_Master_Screen_Inventory.xlsx / .html
- recipe_text_intake_validation_rules.md

Leave unchanged: the Architecture Plan HTML, Pop_Ladle_Actual_Person_10_Step_Paths.md (the latter is impacted but not yet updated — see §7).

---

## 7. Unchanged, pending, and open

**Intentionally unchanged:** Architecture Plan (no relevant section); Layer 2/3 "No bypass" gate tags (accurate as pass-through descriptors).

**Impacted but not yet updated (action needed):**
- **Pop_Ladle_Actual_Person_10_Step_Paths.md** — the *Clinician Reviewer* path still says the system "unlocks the recipe" / "stands between generation and the kitchen" (old mandatory-gate model); Owner step 8 and VA Veteran step 7 ("await/hold until clinical sign-off") need softening to the two-axis model. Profile-entry steps could gain catalog tags. (Offered; not yet done.)

**Optional blueprint parity polish (not correctness):**
- Layer 3: name "Intake Limits" as a feature/screen in the Private Household App.
- Layer 1: name "Verified Credential management" as a control; add "Attestation status" + "Publish state" chips to Master Recipe Library Control.

**Open product decisions (from the handoff):**
1. FDC match strategy (thresholds, composite foods, no-match handling).
2. `target`/`floor` intake-limit types in MVP, or ceilings only.
3. openFDA adverse-events/recalls in/out for MVP (review-packet only if in).
4. Re-attestation scope — reset on any edit vs. nutrition-relevant edits only.
5. Final badge wording (Legal/Compliance + Clinical Editor sign-off).
6. Credential verification flow (MVP = Super Admin manual seed).
7. Developer name for the handoff docs (currently neutral "the developer").

---

## 8. Consistency map (keep these aligned on future edits)

| Concept | Blueprints | ABAC | Recipe Profile | Screen Inventory | Validation Rules | Handoff |
|---|---|---|---|---|---|---|
| Two-axis gate (only Denied blocks) | System + L1 callouts | gate relations + tokens | release rules + attestation | Workflow Gates + Attest screen | After-validation section | gate state machine |
| Credential-gated attestation | L1 Attestation callout | `recipe:clinical_attest` + attr | attestation record | Attest + Credential screens | — | §2/§7 attestation |
| FDC = nutrient source | System/L2 nutrition labels + L1 catalog governance | `clinical_limit:set` | Nutrition Snapshot source | Nutrition Verification Queue | "not an intake field" | §3/§8 nutrition |
| Per-person intake limits | Care Profile fields | Owner/Co-Owner `clinical_limit:set` | downstream interpretation | Intake Limits screen | — | `care_intake_limit` |
| Non-suppressible badge | gate callouts | — | caregiver card status | badge on recipe screens | — | §9 UI |
| Catalog wiring (ICD-10/RxNorm/FDC) | Source-catalog blocks + journey tags | Nutrition Data Manager scope | External Verification Boundary | catalog data objects | — | §3 catalogs |

If you change any one cell's behavior, check the others in its row.
